class Admin {
    constructor(usuario, contraseña, id) {
        this.usario = usuario;
        this.contraseña = contraseña;
        this.id = id;

    }
}

class Huesped {
    constructor(usuario, contraseña, id, cantProp) {
        this.usario = usuario;
        this.contraseña = contraseña;
        this.id = id;
        this.cantProp = cantProp;
    }
}

class Anfitrion {
    constructor(usuario, contraseña, id, propAlquiladas) {
        this.usario = usuario;
        this.contraseña = contraseña;
        this.id = id;
        this.propAlquiladas = propAlquiladas;
    }
}

class Inmueble {
    constructor(titulo, precio, foto, ubi, promedio, desc, id) {
        this.titulo = titulo;
        this.precio = precio;
        this.foto =foto;
        this.ubi = ubi;
        this.promedio = promedio;
        this.desc = desc;
        this.id = id;
    }
}