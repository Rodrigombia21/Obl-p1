class Inmueble{
    constructor (id, titulo, descripcion, ciudad, precio, promedio, foto){
        this.id = id;
        this.titulo = titulo,
        this.descripcion = descripcion;
        this.ciudad = ciudad;
        this.precio = precio;
        this.promedio = promedio;
        this.foto = foto;
            
    }
} 