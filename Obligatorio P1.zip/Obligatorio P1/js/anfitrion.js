class Anfitrion{
    constructor (id, usuario, contrasenia, propiedades){
        this.id = id;
        this.usuario = usuario;
        this.contrasenia = contrasenia;
        this.propiedades = propiedades;
        this.tipo = "anfitrion";
    }
}