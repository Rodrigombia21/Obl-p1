 admin = [new Admin("admin", "1234", 1)];


 huesped = new Huesped("Rodrigo", "Rodrigo1234", 1, 0);


 anfitrion = new Anfitrion("Tomas", "Tomas1234", 1, 0);


 inmuebles = [new Inmueble("hotel california",5000,'casa1.jpg', 'Montevideo', 3, 'Hotel lujo', 1),
              new Inmueble("hotel carrasco",3000,"casa2.jpg", 'Montevideo', 2,'hotel grande', 2 )]; 
             
             
 function mostrarInmuebleEnRango(){
let valorInicial =  Number(document.querySelector("#valorDesde").value);
let valorFinal =  Number(document.querySelector("#valorHasta").value);
               
    for(let i = 0; i< inmuebles;i++){
        if(valorInicial< inmuebles[i].precio && valorFinal > inmuebles[i].precio){
            cargarInmuebles();
        }
        else{
            alert("No hay inmuebles en este rango")
        }
    }

 }
