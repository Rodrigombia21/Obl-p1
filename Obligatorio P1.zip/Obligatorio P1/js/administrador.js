class Administrador{
    constructor (usuario, contrasenia){
        this.usuario = usuario;
        this.contrasenia = contrasenia;
        this.tipo = "admin";
    }
}


let administradores = [
    new Administrador("admin", "1234")
  ]